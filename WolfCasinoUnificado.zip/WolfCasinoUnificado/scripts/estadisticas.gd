extends Control

func _ready() -> void:
	if not GameData.jugador_registrado:
		get_tree().change_scene_to_file("res://scenes/menu_principal.tscn")
		return
	$NombreLabel.text     = "Jugador: " + GameData.jugador_nombre
	$SaldoLabel.text      = "💰 Saldo actual: $" + str(GameData.jugador_saldo)
	$PartidasLabel.text   = "🎮 Partidas totales: " + str(GameData.partidas_jugadas)
	$GanadasLabel.text    = "✅ Ganadas: " + str(GameData.partidas_ganadas)
	$PerdidasLabel.text   = "❌ Perdidas: " + str(GameData.partidas_perdidas)
	$GananciasLabel.text  = "📈 Ganancias totales: $" + str(GameData.ganancias_totales)
	$PerdidasTotLabel.text= "📉 Pérdidas totales: $" + str(GameData.perdidas_totales)
	var balance = GameData.ganancias_totales - GameData.perdidas_totales
	var signo = "+" if balance >= 0 else ""
	$BalanceLabel.text    = "⚖️ Balance neto: " + signo + str(balance)

func _on_btn_volver_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/menu_principal.tscn")
