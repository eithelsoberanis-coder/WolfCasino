extends Control

func _ready() -> void:
	if not GameData.jugador_registrado:
		get_tree().change_scene_to_file("res://scenes/menu_principal.tscn")
		return
	$NombreLabel.text    = "👤 Nombre: " + GameData.jugador_nombre
	$SaldoLabel.text     = "💰 Saldo: $" + str(GameData.jugador_saldo)
	$PartidasLabel.text  = "🎮 Partidas jugadas: " + str(GameData.partidas_jugadas)
	$GanadasLabel.text   = "✅ Ganadas: " + str(GameData.partidas_ganadas)
	$PerdidasLabel.text  = "❌ Perdidas: " + str(GameData.partidas_perdidas)

func _on_btn_volver_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/menu_principal.tscn")
