extends Control

func _ready() -> void:
	$SaldoLabel.text = "💰 Saldo: $" + str(GameData.jugador_saldo)

func _on_btn_blackjack_pressed() -> void:
	get_tree().change_scene_to_file("res://BlackJack/jugar_black_jack.tscn")

func _on_btn_ruleta_pressed() -> void:
	get_tree().change_scene_to_file("res://ruleta/ruleta.tscn")

func _on_btn_carreras_pressed() -> void:
	get_tree().change_scene_to_file("res://Carrera_Caballos/scenes/Main.tscn")

func _on_btn_volver_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/menu_principal.tscn")
